## README

Evaluar los siguientes links:

[Method model_name](http://api.rubyonrails.org/classes/ActiveModel/Naming.html#method-i-model_name) |
[Friendly URLS](http://danielagattoni.quiltyweb.com/crear-url-friendly-en-ruby-on-rails-en-5-pasos/#comment-51) |

