class Post < ApplicationRecord
  after_create :update_slug
  before_update :assign_slug

  def to_param
    slug
  end

  private

  def assign_slug
    postname = Post.model_name.name
    self.slug = postname.pluralize + "/" + "#{title.parameterize}"
  end

  def update_slug
    update_attributes slug: assign_slug
  end
end
